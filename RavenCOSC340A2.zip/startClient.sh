#!/bin/bash

clear
echo "Attempting to start Client with port '$1'"
python client.py $1