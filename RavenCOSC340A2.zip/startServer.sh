#!/bin/bash

clear
echo "Attempting to start Server with port '$1'"
python server.py $1